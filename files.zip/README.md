# N Puzzle Solver

Python solver for the HackerRank **N Puzzle** challenge (HackerRank Orchestrate, October 2026).
Problem: https://www.hackerrank.com/challenges/n-puzzle

## Problem

Slide the tiles of a `k x k` grid (`3 <= k <= 5`) into the goal configuration using as few moves as possible. The empty cell is `0`, and each output move describes the movement of the empty cell (`UP`, `DOWN`, `LEFT`, `RIGHT`).

Goal state (for `k = 3`):

```
0 1 2
3 4 5
6 7 8
```

**Input:** `k`, then `k * k` integers (one per line), top-left to bottom-right.
**Output:** the number of moves `M`, then `M` lines of moves. Unsolvable boards print `-1`.

## Approach

1. **Solvability check** using inversion parity (with the blank-row adjustment for even `k`), so impossible boards are rejected immediately.
2. **IDA\*** search, which keeps memory use low.
3. **Manhattan distance** heuristic, updated incrementally for each move.
4. **Weighted IDA\*** with a decreasing weight schedule (3.0, 2.0, 1.5, 1.25, 1.0) under a time budget. A fast, loose search gives a valid answer first, and later passes try to shorten it. When the weight reaches 1.0 and finishes, the result is optimal.

## Usage

```bash
python3 n_puzzle.py < sample_input.txt
```

Change `TIME_BUDGET` at the top of `n_puzzle.py` (default 7 seconds) to match the time limit you are working with.

## Notes from testing

- The sample board (`k = 3`) is solved optimally in 20 moves.
- Random 3x3 boards solve optimally in well under a second.
- Random 5x5 boards are too hard for optimal search in Python within the time budget, so the solver returns a valid but longer solution (about 166 to 240 moves in my runs). Better heuristics (pattern databases) or a faster language would improve this.
- Every output was replayed move by move to confirm it reaches the goal.

## Possible improvements

- Linear-conflict or pattern-database heuristics for tighter bounds
- A C++ or PyPy implementation for deeper searches
