import sys, time

DIRS = [("UP", -1, 0), ("DOWN", 1, 0), ("LEFT", 0, -1), ("RIGHT", 0, 1)]
OPP = {"UP": "DOWN", "DOWN": "UP", "LEFT": "RIGHT", "RIGHT": "LEFT"}
TIME_BUDGET = 7.0  # seconds; lower it if the judge's limit is tighter


class Timeout(Exception):
    pass


def solvable(k, board):
    flat = [v for v in board if v]
    inv = sum(1 for i in range(len(flat)) for j in range(i + 1, len(flat)) if flat[i] > flat[j])
    if k % 2 == 1:
        return inv % 2 == 0
    return (inv + board.index(0) // k) % 2 == 0   # goal blank is on row 0


def solve(k, board, deadline):
    n = k * k
    # goal: value v sits at index v
    # man[v][i] = Manhattan distance of tile v placed at index i
    man = [[abs(i // k - v // k) + abs(i % k - v % k) for i in range(n)] for v in range(n)]
    nbr = []
    for z in range(n):
        r, c = divmod(z, k)
        nbr.append([(nm, (r + dr) * k + c + dc) for nm, dr, dc in DIRS
                    if 0 <= r + dr < k and 0 <= c + dc < k])

    best = None
    b = board[:]
    path = []
    counter = [0]

    def run(w, limit):
        # weighted IDA*; limit = max allowed solution length (exclusive)
        res = []

        def dfs(g, h, z, last, bound):
            counter[0] += 1
            if counter[0] & 0xFFF == 0 and time.time() > deadline:
                raise Timeout
            f = g + w * h
            if f > bound:
                return f
            if h == 0:
                res.extend(path)
                return -1
            if g + h >= limit:
                return 1e9
            mn = 1e9
            for nm, nz in nbr[z]:
                if last and OPP[last] == nm:
                    continue
                v = b[nz]
                nh = h - man[v][nz] + man[v][z]
                b[z] = v; b[nz] = 0
                path.append(nm)
                t = dfs(g + 1, nh, nz, nm, bound)
                path.pop()
                b[z] = 0; b[nz] = v
                if t == -1:
                    return -1
                if t < mn:
                    mn = t
            return mn

        z0 = b.index(0)
        hm = sum(man[v][i] for i, v in enumerate(b) if v)
        bound = w * hm
        while True:
            t = dfs(0, hm, z0, None, bound)
            if t == -1:
                return res
            if t >= 1e9:
                return None
            bound = t

    for w in (3.0, 2.0, 1.5, 1.25, 1.0):
        try:
            limit = len(best) if best is not None else 10**9
            r = run(w, limit)
        except Timeout:
            break
        if r is not None and (best is None or len(r) < len(best)):
            best = r
        if w == 1.0:
            break
        if r is None:      # nothing shorter than best exists under this weight
            continue
    return best


def main():
    data = sys.stdin.read().split()
    k = int(data[0])
    board = list(map(int, data[1:1 + k * k]))
    if not solvable(k, board):
        print(-1)
        return
    res = solve(k, board, time.time() + TIME_BUDGET)
    print(len(res))
    if res:
        print("\n".join(res))


if __name__ == "__main__":
    main()
